# NOVA AI V3 — Android starter

## অন্তর্ভুক্ত
- বাংলা bn-BD Speech Recognition ও Text-to-Speech
- ভয়েসে ইনস্টল করা অ্যাপের নাম বললে অ্যাপ খোলা (যেমন “YouTube খোলো”)\n- Settings খোলা, Back, scroll up/down
- Accessibility tree-তে প্রকাশিত দৃশ্যমান লেখা পড়া
- label দিয়ে clickable UI element-এ tap করার চেষ্টা
- GitHub Actions-এ debug APK build এবং artifact upload

## ফোন থেকে APK
1. ZIP extract করে ভেতরের সব ফাইল GitHub repository-র root-এ upload করো; `.github/workflows/android.yml`-এর path ঠিক রাখতে হবে।
2. default branch `main` রাখো (অথবা workflow-তে branch-এর নাম বদলাও)।
3. GitHub → Actions → Build NOVA AI APK → Run workflow।
4. সফল হলে run page-এর Artifacts থেকে `NOVA-AI-debug-APK` download করো; ZIP extract করে `app-debug.apk` install করো।

## প্রথমবার
- Microphone permission দাও।
- Accessibility চালু করুন → Android Settings → Accessibility → NOVA AI চালু করো। সতর্কতা পড়ে বুঝে অনুমতি দাও।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি পূর্ণ AI agent নয়; কোনো LLM/API যুক্ত নেই। স্ক্রিনের শুধু Accessibility-তে প্রকাশিত text/contentDescription পড়ে; ছবি, ভিডিও, protected content বা canvas text বোঝে না। Tap-by-label best effort এবং সব অ্যাপে কাজ নাও করতে পারে। Always-on listening, screenshot/OCR, online AI reasoning, নিরাপদ API key ব্যবস্থা ও জটিল app workflow এখনো নেই। Android version, speech provider, নির্মাতা ও app UI অনুযায়ী ফল আলাদা হতে পারে। কোনো build বা runtime-এ zero-error নিশ্চয়তা দেওয়া সম্ভব নয়।
