package com.nova.ai
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity:ComponentActivity(),TextToSpeech.OnInitListener {
 private var tts:TextToSpeech?=null
 private var recognizer:SpeechRecognizer?=null
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);tts=TextToSpeech(this,this);setContent{Screen()}}
 override fun onInit(status:Int){tts?.language=Locale("bn","BD")}
 private fun say(s:String){tts?.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nova")}
 private fun listen(status:(String)->Unit,result:(String)->Unit){
  if(!SpeechRecognizer.isRecognitionAvailable(this)){status("Speech Recognition পাওয়া যায়নি।");return}
  recognizer?.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this)
  recognizer?.setRecognitionListener(object:RecognitionListener{
   override fun onReadyForSpeech(p:Bundle?){status("শুনছি…")}
   override fun onBeginningOfSpeech(){}; override fun onRmsChanged(v:Float){}; override fun onBufferReceived(b:ByteArray?){}
   override fun onEndOfSpeech(){status("প্রক্রিয়া করছি…")}
   override fun onError(e:Int){status("শোনা যায়নি। আবার চেষ্টা করো। ($e)")}
   override fun onResults(b:Bundle?){result(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty())}
   override fun onPartialResults(b:Bundle?){}; override fun onEvent(e:Int,b:Bundle?){}
  })
  val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);putExtra(RecognizerIntent.EXTRA_LANGUAGE,"bn-BD")}
  recognizer?.startListening(i)
 }
 private fun launchAppBySpokenName(raw:String):String {
  val cleaned = raw.lowercase()
   .replace("খোলো","").replace("ওপেন","").replace("চালু করো","")
   .replace("open","").replace("launch","").trim()
  if(cleaned.isBlank()) return "কোন অ্যাপ খুলতে হবে বলো।"
  val apps = packageManager.getInstalledApplications(0)
  val match = apps.firstOrNull { app ->
   packageManager.getApplicationLabel(app).toString().lowercase().contains(cleaned)
  }
  if(match != null) {
   val launch = packageManager.getLaunchIntentForPackage(match.packageName)
   if(launch != null) { startActivity(launch); return "${packageManager.getApplicationLabel(match)} খুলছি।" }
  }
  return "$cleaned নামে অ্যাপ খুঁজে পাইনি। অ্যাপের নামটি আবার বলো।"
 }
 private fun command(raw:String):String {
  val q=raw.lowercase(); val svc=NovaAccessibilityService.instance
  val answer=when {
   q.contains("খোলো")||q.contains("ওপেন")||q.contains("চালু করো")||q.startsWith("open ")||q.startsWith("launch ")->launchAppBySpokenName(raw)
   q.contains("সেটিং")||q.contains("setting")-> {startActivity(Intent(Settings.ACTION_SETTINGS));"ফোনের সেটিংস খুলছি।"}
   q.contains("ব্যাক")||q=="back"||q.contains("পিছনে যাও")-> {if(svc!=null){svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK);"পেছনে যাচ্ছি।"}else "আগে NOVA AI Accessibility চালু করো।"}
   q.contains("স্ক্রল নিচে")||q.contains("নিচে যাও")||q.contains("scroll down")->if(svc?.scroll(true)==true)"নিচে স্ক্রল করেছি।" else "স্ক্রল করতে পারিনি। Accessibility চালু করো।"
   q.contains("স্ক্রল উপরে")||q.contains("উপরে যাও")||q.contains("scroll up")->if(svc?.scroll(false)==true)"উপরে স্ক্রল করেছি।" else "স্ক্রল করতে পারিনি। Accessibility চালু করো।"
   q.contains("স্ক্রিন পড়")||q.contains("স্ক্রিনে কী")||q.contains("read screen")->svc?.readVisibleText() ?: "স্ক্রিন পড়তে Accessibility চালু করো।"
   q.startsWith("ট্যাপ ")||q.startsWith("tap ")||q.startsWith("ক্লিক ")->{val label=raw.substringAfter(' ').trim();if(label.isNotBlank()&&svc?.clickByLabel(label)==true)"‘$label’ চাপ দিয়েছি।" else "‘$label’ নামে ক্লিকযোগ্য কিছু পাইনি।"}
   q.contains("accessibility")||q.contains("অ্যাক্সেসিবিলিটি")-> {startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));"Accessibility সেটিংস খুলছি।"}
   q.contains("হ্যালো")||q.contains("hello")||q.contains("তুমি কে")->"আমি NOVA AI। তোমার ভয়েস কমান্ডে সাহায্য করার জন্য তৈরি।"
   else->"এই কমান্ডটি এখনো যোগ করা হয়নি। সেটিংস, ব্যাক, স্ক্রল, স্ক্রিন পড়া বা ট্যাপ বলে চেষ্টা করো।"
  };say(answer);return answer
 }
 @Composable private fun Screen(){
  var heard by remember{mutableStateOf("এখানে তোমার কথা দেখা যাবে।")}
  var reply by remember{mutableStateOf("আমি প্রস্তুত। মাইক্রোফোনে চাপ দাও।")}
  var status by remember{mutableStateOf("প্রস্তুত")}
  var allowed by remember{mutableStateOf(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)}
  val ask=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){allowed=it;if(!it)status="মাইক্রোফোন permission দরকার।"}
  MaterialTheme {
   Surface(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
     Text("NOVA AI",style=MaterialTheme.typography.headlineLarge);Text("বাংলা ভয়েস অ্যাসিস্ট্যান্ট • Android prototype")
     AssistChip(onClick={},label={Text(status)})
     Button(onClick={if(!allowed)ask.launch(Manifest.permission.RECORD_AUDIO) else listen({status=it},{heard=it;reply=command(it)})},modifier=Modifier.fillMaxWidth()){Text("🎙 কথা বলুন")}
     OutlinedButton(onClick={startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))},modifier=Modifier.fillMaxWidth()){Text("Accessibility চালু করুন")}
     OutlinedButton(onClick={startActivity(Intent(Settings.ACTION_SETTINGS))},modifier=Modifier.fillMaxWidth()){Text("ফোনের Settings খুলুন")}
     Text("তুমি বলেছ:",style=MaterialTheme.typography.titleMedium);Text(heard)
     HorizontalDivider();Text("NOVA-এর উত্তর:",style=MaterialTheme.typography.titleMedium);Text(reply)
     HorizontalDivider();Text("কমান্ড: সেটিংস খোলো • ব্যাক যাও • স্ক্রল নিচে/উপরে • স্ক্রিন পড়ে শোনাও • ট্যাপ Search")
     Text("সীমাবদ্ধতা: এটি এখনো পূর্ণ AI নয়। Accessibility-তে প্রকাশিত লেখা পড়তে পারে; সব অ্যাপের ছবি/OCR বোঝা, সব UI-তে কাজ করা বা সবসময় ব্যাকগ্রাউন্ডে শোনা সমর্থিত নয়।")
    }
   }
  }
 }
 override fun onDestroy(){recognizer?.destroy();tts?.shutdown();super.onDestroy()}
}
