package com.nova.ai
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
class NovaAccessibilityService: AccessibilityService() {
 override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
 override fun onInterrupt() {}
 companion object { @Volatile var instance: NovaAccessibilityService? = null }
 override fun onServiceConnected(){ super.onServiceConnected(); instance=this }
 override fun onDestroy(){ if(instance===this) instance=null; super.onDestroy() }
 fun readVisibleText(): String {
  val root=rootInActiveWindow ?: return "স্ক্রিনের লেখা পড়া যাচ্ছে না।"
  val b=StringBuilder(); collect(root,b)
  return b.toString().trim().ifBlank{"পড়ার মতো কোনো লেখা পাওয়া যায়নি।"}
 }
 private fun collect(n: AccessibilityNodeInfo?, b: StringBuilder) {
  if(n==null || b.length>5000) return
  val t=n.text?.toString()?.trim().orEmpty(); val d=n.contentDescription?.toString()?.trim().orEmpty()
  if(t.isNotBlank()) b.append(t).append('\n') else if(d.isNotBlank()) b.append(d).append('\n')
  for(i in 0 until n.childCount) collect(n.getChild(i),b)
 }
 fun clickByLabel(label:String):Boolean {
  val root=rootInActiveWindow ?: return false
  return findClick(root,label.trim().lowercase())
 }
 private fun findClick(n:AccessibilityNodeInfo?, label:String):Boolean {
  if(n==null) return false
  val t=n.text?.toString().orEmpty().lowercase(); val d=n.contentDescription?.toString().orEmpty().lowercase()
  if((t.contains(label)||d.contains(label)) && n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
  for(i in 0 until n.childCount) if(findClick(n.getChild(i),label)) return true
  return false
 }
 fun scroll(down:Boolean):Boolean {
  val root=rootInActiveWindow ?: return false
  return root.performAction(if(down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
 }
}
